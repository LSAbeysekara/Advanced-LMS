<?php include('../Student/config/constant.php'); ?>

<?php
    $cus_id = "cus001";
    $order_total = "12345";
    $pro_id = 3;
    $quantity = 100;
    $p_s_price = 1002;


    $name = $_GET['name'];
    $address = $_GET['address'];
    $zip = $_GET['zip'];
    $mobile = $_GET['mobile'];
    $email = $_GET['email'];

    date_default_timezone_set('Asia/Colombo');
    $currentDateTime = date('Y-m-d H:i:s');
?>

<?php
//first table
$sql1 = "INSERT INTO tb_order SET
     order_total = '$order_total',
     order_status = 'PAID',
     pay_method = 'Online',
     order_date = '$currentDateTime',
     cust_id = '$cus_id',
     cus_name = '$name',
     mobile = '$mobile',
     d_address = '$address',
     zip = '$zip'
 ";

$res1 = mysqli_query($conn, $sql1);


$sql3 = "SELECT * FROM tb_order ORDER BY order_id DESC LIMIT 1";

        $res3 = mysqli_query($conn, $sql3);

        $count3 = mysqli_num_rows($res3);

        if($count3>0){
            while($row=mysqli_fetch_assoc($res3)){

                $order_id = $row['order_id'];
            }}


//second table
$sql2 = "INSERT INTO tb_order_details SET
     order_id = '$order_id',
     pro_id = '$pro_id',
     quantity = '$quantity',
     p_s_price = '$p_s_price'
 ";

$res2 = mysqli_query($conn, $sql2);




if($res1 == TRUE && $res2 == TRUE) {

    $_SESSION['order-details-add-ok'] = "Added";
    header('location: ./cart.php');

}else{
    $_SESSION['order-details-add-error'] = "error";
    header('location: ./cart.php');
}

?>
