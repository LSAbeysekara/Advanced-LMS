<?php  include('../Student/config/constant.php'); ?>

<?php
    $cus_id = "cus001";


$amount = "2500";
$merchant_id = "1223737";
$order_id = uniqid();
$merchant_secret = "MTM1MTQ1ODA0NDQyOTA5MDI0MDkxNDk2Mzc4NzQwMTI4OTM5Njc5Mg==";
$currency = "LKR";

$hash = strtoupper(
    md5(
        $merchant_id . 
        $order_id . 
        number_format($amount, 2, '.', '') . 
        $currency .  
        strtoupper(md5($merchant_secret)) 
    ) 
);

$array = [];

$array["name"] = "Merchant";
$array["amount"] = $amount;
$array["merchant_id"] = $merchant_id;
$array["order_id"] = $order_id;
$array["currency"] = $currency;
$array["hash"] = $hash; 

$jsonObj = json_encode($array);

echo $jsonObj;
?>
