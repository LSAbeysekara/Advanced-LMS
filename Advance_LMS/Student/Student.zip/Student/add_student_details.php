<?php
include('config/constant.php');

if (!isset($_SESSION['username']) || ($_SESSION['status'] != 'Active')) {
    echo "<script> window.location.replace('http://localhost:3000/login'); </script>";
} else if ($_SESSION['status'] == 'Pending') {
    echo "<script> window.location.replace('http://localhost:8080/Advance_LMS/Student/pending_students.php'); </script>";
}else{

if(isset($_POST['submit'])){

    $name = $_POST["name"];
    $nic = $_POST["nic"];
    $mobile = $_POST["mobile"];
    $dob = $_POST["dob"];
    $address = $_POST["address"];
    $username = $_POST["username"];
    $active = "active";

    $sql = "UPDATE `tb_student` SET `st_name`='$name', `address`='$address', `mobile`='$mobile', `date_of_birth`='$dob', `nic`='$nic', `status`='$active' WHERE `username`='$username'";
    $res = mysqli_query($conn, $sql);

    if($res == true){

        $_SESSION['add-details-ok'] = "OK";
        header("Location: ./profile_pic_upload.php");

    }
    else
    {
        $_SESSION['add-details-error'] = "error";
        header("Location: ./pending_students.php");
        
    }

}else{
    $_SESSION['add-details-error'] = "error";
    header("Location: ./pending_students.php");
}

}
?>