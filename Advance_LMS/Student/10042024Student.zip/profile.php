<?php include('config/constant.php'); 
session_start();?>

<?php
    $username = $_SESSION['username'];
    $st_id = $_SESSION['st_id'];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Student Profile</title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon.png">
    <!-- Custom Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
    <style>
        .cont {
            display: flex;
        }

        .left,
        .right {
            flex: 1;
            margin-right: 20px;
        }

        .edit-button {
            background-color: #0F73E0;
            border: none;
            color: white;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin-top: 10px;
            cursor: pointer;
            border-radius: 5px; 
        }

        .edit-button:hover {
            background-color: #054890;
        }

    </style>
</head>

<body>

    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="loader">
            <svg class="circular" viewBox="25 25 50 50">
                <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="3" stroke-miterlimit="10" />
            </svg>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->

    
    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <!--**********************************
            Nav header start
        ***********************************-->
        <div class="nav-header">
            <div class="brand-logo">
                <a href="index.php">
                    <b class="logo-abbr"><img src="images/logo.png" alt=""> </b>
                    <span class="logo-compact"><img src="./images/logo-compact.png" alt=""></span>
                    <span class="brand-title">
                        <img src="images/logo-text.png" alt="">
                    </span>
                </a>
            </div>
        </div>
        <!--**********************************
            Nav header end
        ***********************************-->

        <!--**********************************
            Header start
        ***********************************-->
        <div class="header">    
            <div class="header-content clearfix">
                <div class="nav-control">
                    <div class="hamburger">
                        <span class="toggle-icon"><i class="icon-menu"></i></span>
                    </div>
                </div>
                <div class="header-right">
                    <ul class="clearfix">
                        <li class="icons dropdown"><a href="javascript:void(0)" data-toggle="dropdown">
                                <i class="mdi mdi-email-outline"></i>
                                <span class="badge gradient-1 badge-pill badge-primary">3</span>
                            </a>
                            <div class="drop-down animated fadeIn dropdown-menu">
                                <div class="dropdown-content-heading d-flex justify-content-between">
                                    <span class="">3 New Messages</span>  
                                    
                                </div>
                                <div class="dropdown-content-body">
                                    <ul>
                                        <li class="notification-unread">
                                            <a href="javascript:void()">
                                                <img class="float-left mr-3 avatar-img" src="images/avatar/1.jpg" alt="">
                                                <div class="notification-content">
                                                    <div class="notification-heading">Saiful Islam</div>
                                                    <div class="notification-timestamp">08 Hours ago</div>
                                                    <div class="notification-text">Hi Teddy, Just wanted to let you ...</div>
                                                </div>
                                            </a>
                                        </li>
                                        <li class="notification-unread">
                                            <a href="javascript:void()">
                                                <img class="float-left mr-3 avatar-img" src="images/avatar/2.jpg" alt="">
                                                <div class="notification-content">
                                                    <div class="notification-heading">Adam Smith</div>
                                                    <div class="notification-timestamp">08 Hours ago</div>
                                                    <div class="notification-text">Can you do me a favour?</div>
                                                </div>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="javascript:void()">
                                                <img class="float-left mr-3 avatar-img" src="images/avatar/3.jpg" alt="">
                                                <div class="notification-content">
                                                    <div class="notification-heading">Barak Obama</div>
                                                    <div class="notification-timestamp">08 Hours ago</div>
                                                    <div class="notification-text">Hi Teddy, Just wanted to let you ...</div>
                                                </div>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="javascript:void()">
                                                <img class="float-left mr-3 avatar-img" src="images/avatar/4.jpg" alt="">
                                                <div class="notification-content">
                                                    <div class="notification-heading">Hilari Clinton</div>
                                                    <div class="notification-timestamp">08 Hours ago</div>
                                                    <div class="notification-text">Hello</div>
                                                </div>
                                            </a>
                                        </li>
                                    </ul>
                                    
                                </div>
                            </div>
                        </li>
                        <li class="icons dropdown"><a href="javascript:void(0)" data-toggle="dropdown">
                                <i class="mdi mdi-bell-outline"></i>
                                <span class="badge badge-pill gradient-2 badge-primary">3</span>
                            </a>
                            <div class="drop-down animated fadeIn dropdown-menu dropdown-notfication">
                                <div class="dropdown-content-heading d-flex justify-content-between">
                                    <span class="">2 New Notifications</span>  
                                    
                                </div>
                                <div class="dropdown-content-body">
                                    <ul>
                                        <li>
                                            <a href="javascript:void()">
                                                <span class="mr-3 avatar-icon bg-success-lighten-2"><i class="icon-present"></i></span>
                                                <div class="notification-content">
                                                    <h6 class="notification-heading">Events near you</h6>
                                                    <span class="notification-text">Within next 5 days</span> 
                                                </div>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="javascript:void()">
                                                <span class="mr-3 avatar-icon bg-danger-lighten-2"><i class="icon-present"></i></span>
                                                <div class="notification-content">
                                                    <h6 class="notification-heading">Event Started</h6>
                                                    <span class="notification-text">One hour ago</span> 
                                                </div>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="javascript:void()">
                                                <span class="mr-3 avatar-icon bg-success-lighten-2"><i class="icon-present"></i></span>
                                                <div class="notification-content">
                                                    <h6 class="notification-heading">Event Ended Successfully</h6>
                                                    <span class="notification-text">One hour ago</span>
                                                </div>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="javascript:void()">
                                                <span class="mr-3 avatar-icon bg-danger-lighten-2"><i class="icon-present"></i></span>
                                                <div class="notification-content">
                                                    <h6 class="notification-heading">Events to Join</h6>
                                                    <span class="notification-text">After two days</span> 
                                                </div>
                                            </a>
                                        </li>
                                    </ul>
                                    
                                </div>
                            </div>
                        </li>
                        
                        <li class="icons dropdown">
                            <div class="user-img c-pointer position-relative"   data-toggle="dropdown">
                                <span class="activity active"></span>
                                <img src="images/profile-pic/default.png" height="40" width="40" alt="">
                            </div>
                            <div class="drop-down dropdown-profile   dropdown-menu">
                                <div class="dropdown-content-body">
                                    <ul>
                                        <li>
                                            <a href="profile.php"><i class="icon-user"></i> <span>Profile</span></a>
                                        </li>
                                        <li>
                                            <a href="email-inbox.php"><i class="icon-envelope-open"></i> <span>Inbox</span> <div class="badge gradient-3 badge-pill badge-primary">3</div></a>
                                        </li>
                                        
                                        <hr class="my-2">
                                        <li>
                                            <a href="page-lock.php"><i class="icon-lock"></i> <span>Lock Screen</span></a>
                                        </li>
                                        <li><a href="page-login.php"><i class="icon-key"></i> <span>Logout</span></a></li>
                                    </ul>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <!--**********************************
            Header end ti-comment-alt
        ***********************************-->

        <!--**********************************
            Sidebar start
        ***********************************-->
        <div class="nk-sidebar">
            <div class="nk-nav-scroll">
                <ul class="metismenu" id="menu">
                    <li class="nav-label">Dashboard</li>
                        <li>
                            <a class="has-arrow" href="javascript:void()" aria-expanded="false">
                                <i class="icon-home menu-icon"></i><span class="nav-text">My Courses</span>
                            </a>
                            <ul aria-expanded="false">
                                <li><a href="./course.php">First Module</a></li>
                                <li><a href="./course.php">Second Module</a></li>
                                <!-- <li><a href="./index-2.php">Home 2</a></li> -->
                            </ul>
                        </li>
                    </li>
                    <li class="nav-label">Course</li>
                        <li>
                            <a class="has-arrow" href="javascript:void()" aria-expanded="false">
                                <i class="icon-speedometer menu-icon"></i><span class="nav-text">Lessons</span>
                            </a>
                            <ul aria-expanded="false">
                                <li><a href="./add-lesson.php">Add Lesson</a></li>
                                <li><a href="./course.php">Lessons</a></li>
                            </ul>
                        </li>
                        <li>
                            <a class="has-arrow" href="javascript:void()" aria-expanded="false">
                                <i class="icon-speedometer menu-icon"></i><span class="nav-text">Assignments</span>
                            </a>
                            <ul aria-expanded="false">
                                <li><a href="./add-assignment.php">Add an assignment</a></li>
                                <li><a href="./assignments.php">Assignments</a></li>
                            </ul>
                        </li>
                        <li>
                            <a class="has-arrow" href="javascript:void()" aria-expanded="false">
                                <i class="icon-speedometer menu-icon"></i><span class="nav-text">Students</span>
                            </a>
                            <ul aria-expanded="false">
                                <li><a href="./students.php">Students</a></li>
                            </ul>
                        </li>
                    </li>
                </ul>
            </div>
        </div>
        <!--**********************************
            Sidebar end
        ***********************************-->

        <!--**********************************
            Content body start
        ***********************************-->
        <?php
        

        $sql = "SELECT * FROM `tb_student` where username='$username'"; // Adjust the table and column names

        $result = $conn->query($sql);


        while ($row = $result->fetch_assoc()) {

        ?>
        <div class="content-body">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-4 col-xl-3" style="min-width: 40%;">
                        <div class="card">
                            <div class="card-body">
                                <div class="media align-items-center mb-4">
                                    <img class="mr-3" src="./images/profile-pic/<?php echo $row['pro_img'] ?>" alt="" width="120px" height="120px">
                                </div>

                                <h2>Info</h2>

                                <div class="cont">
                                    <div class="left">
                                        <div class="media-body">
                                            <li><strong class="text-dark mr-4">Name</strong></br> <span>
                                                <?php
                                                    if($row['st_name'] == NULL){
                                                        echo "Not activated yet";
                                                    }else{
                                                        echo $row['st_name']; 
                                                    }
                                                ?>
                                            </span></li><br>
                                            <li><strong class="text-dark mr-4">Username</strong></br> <span><?php echo $row['username'] ?></span></li><br>
                                        </div>
                                        
                                        <ul class="card-profile__info">    
                                            <li><strong class="text-dark mr-4">Email</strong></br> <span><?php echo $row['email'] ?></span></li><br>
                                            <li><strong class="text-dark mr-4">Date of Birth</strong></br> <span><?php echo $row['date_of_birth'] ?></span></li><br>
                                            <li><strong class="text-dark mr-4">NIC</strong> </br><span>
                                                <?php
                                                    if($row['nic'] == NULL){
                                                        echo "Not activated yet";
                                                    }else{
                                                        echo $row['nic']; 
                                                    }
                                                ?>
                                            </span></li><br>

                                        </ul>
                                    </div>
                                    <div class="right">
                                        <div class="media-body">
                                            <li><strong class="text-dark mr-4">Address</strong></br> <span><?php echo $row['address'] ?></span></li><br>
                                        </div>
                                        
                                        <ul class="card-profile__info">    
                                            <li><strong class="text-dark mr-4">Mobile Number</strong></br> <span><?php echo $row['mobile'] ?></span></li><br>
                                            <li><strong class="text-dark mr-4">Joined Date</strong></br> <span><?php echo $row['joined_date'] ?></span></li><br>
                                            <li><strong class="text-dark mr-4">Status</strong> </br><span>
                                                <?php
                                                    if($row['nic'] == NULL){
                                                        echo "Not activated yet";
                                                    }else{ ?>
                                                        <div style="color: green;"><?php echo "Active"; ?></div> <?php
                                                    }
                                                ?>
                                            </span></li><br>
                                            <li><strong class="text-dark mr-4">Seller Account</strong> </br><span>
                                                <?php
                                                    if($row['seller'] == "inactive"){ ?>
                                                        <div style="color: red;"><?php echo "Not registered as a seller"; ?></div> <?php
                                                    }else{ ?>
                                                        <div style="color: green;"><?php echo "Activated"; ?></div> <?php
                                                    }
                                                ?>
                                            </span></li><br>
                                        </ul>
                                    </div>
                                </div>

                                <div style="text-align: center;">
                                    <a href="edit_profile.php?username=<?php echo $username; ?>"><button class="edit-button">Edit profile</button></a>
                                </div>
                                
                            </div>
                        </div>  
                    </div>
                    
                    <div class="col-lg-8 col-xl-1" style="min-width: 60%;">

                        <div class="card">
                            <div class="card-body">
                             <h3>Courses Enrolled</h3>

                            <?php
                            $sql1 = "SELECT * FROM `tb_enrollment` where st_id='$st_id'";

                            $result1 = $conn->query($sql1);

                            while ($row = $result1->fetch_assoc()) { 

                                $c_id = $row['course_id'];
                                
                                
                                $sql2 = "SELECT * FROM `tb_courses` where c_id='$c_id'";

                                $result2 = $conn->query($sql2);

                                while ($row = $result2->fetch_assoc()) { 
                                ?>
                                    <br><a href="course_view.php?c_id=<?php echo $c_id; ?>"><?php echo $row['c_name']; ?></a><br>
                            <?php
                                }
                            }
                                ?>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #/ container --><?php } ?>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->
        
        
        <!--**********************************
            Footer start
        ***********************************-->
        <div class="footer">

        </div>
        <!--**********************************
            Footer end
        ***********************************-->
    </div>
    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
    <script src="plugins/common/common.min.js"></script>
    <script src="js/custom.min.js"></script>
    <script src="js/settings.js"></script>
    <script src="js/gleek.js"></script>
    <script src="js/styleSwitcher.js"></script>

</body>

</html>